import { Component, EventEmitter, Input, OnInit, Output,ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl ,FormArray} from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { NgModule } from '@angular/core';
import { Observable } from 'rxjs'; 
import { BrowserModule } from '@angular/platform-browser';
import { map, startWith } from 'rxjs/operators';
import * as service from '../../../api-service/service/index';
import { Router,ActivatedRoute } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';

import { PasswordMatchPattern } from '../../../api-service/all-validation-pattern/password-match-pattern';
import { MobilePatternValidator } from '../../../api-service/all-validation-pattern/mobile-pattern-validator';

declare const $: any;
declare const google: any;
import AOS from 'aos';
import 'aos/dist/aos.css';

import { ImageCroppedEvent } from 'ngx-image-cropper';


@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent implements OnInit {

  public onlineUserData;
  public total_distance=0;
  public allEventData;
  public title_heading;
  public pending_data:boolean=false;
  public bodydata: any = {};

  public event_id;
  public roomData;

  imgChangeEvt: any = "";
  cropImgPreview: any = "";
  public id_proof_1='';

  imgChangeEvtNew: any = "";
  cropImgPreviewNew: any = "";
  public id_proof_2='';
  public addNewMemberFlag:boolean=false;

  public profile_type;

  public eventForm: FormGroup;
  public submitted = false;
  public base64Image1;
  public userData;
  public eventPrice;
  public eventProfileType;


  public showname;
  public userflag: any;
  public showflag;
  public userid: string;
  public uservalue;
  public usenameArray=[];

  constructor(private formBuilder: FormBuilder,
                private callapi: service.CallApiService,
                private tokenSaveService: service.CanTokenSaveService,
                private router: Router,
                private toastr: ToastrManager,
                private tokenRemoveService: service.CanTokenRemoveService,
                public commonServe: service.CommonService,private activatedRoute: ActivatedRoute)
  { 
    if (!(this.tokenSaveService.getAccessToken())) {
        this.router.navigateByUrl('/home');
    }
  }

  ngOnInit() {

     setTimeout(() => {
        $('#right_side_togle').removeClass('show_toggle');
        $('#right_side_togle').addClass('hide_toggle');

        $('#big_tab').removeClass('col-lg-8');
        $('#big_tab').addClass('col-lg-10');
        this.profile_type = this.tokenSaveService.getProfileType();

        if(this.profile_type == 'single'){

           this.eventForm = this.formBuilder.group({
              full_name: new FormControl('', [Validators.required]),
              username: new FormControl('', [Validators.required]),
              email: new FormControl('', [Validators.required]),
              mobile: new FormControl('', [Validators.required]),
              id_proof: new FormControl('', [Validators.required]),

              full_name1: new FormControl(''),
              username1: new FormControl(''),
              email1: new FormControl(''),
              mobile1: new FormControl(''),
              id_proof1: new FormControl(''),

              items: this.formBuilder.array([])
              
            });
        }else if(this.profile_type == 'couple'){

           this.eventForm = this.formBuilder.group({
              full_name: new FormControl('', [Validators.required]),
              username: new FormControl('', [Validators.required]),
              email: new FormControl('', [Validators.required]),
              mobile: new FormControl('', [Validators.required]),
              id_proof: new FormControl('', [Validators.required]),

              full_name1: new FormControl('', [Validators.required]),
              username1: new FormControl('', [Validators.required]),
              email1: new FormControl('', [Validators.required]),
              mobile1: new FormControl('', [Validators.required]),
              id_proof1: new FormControl('', [Validators.required]),
              

              items: this.formBuilder.array([])
              
            });


        }else{
            this.eventForm = this.formBuilder.group({
              full_name: new FormControl('', [Validators.required]),
              username: new FormControl('', [Validators.required]),
              email: new FormControl('', [Validators.required]),
              mobile: new FormControl('', [Validators.required]),
              id_proof: new FormControl('', [Validators.required]),

              full_name1: new FormControl(''),
              username1: new FormControl(''),
              email1: new FormControl(''),
              mobile1: new FormControl(''),
              id_proof1: new FormControl(''),

              items: this.formBuilder.array([])
              
            });
        }
        
        this.event_id = atob(this.activatedRoute.snapshot.queryParams["event_id"]);
        this.getallFriendRequest(this.event_id);
        
     }, 2000);

   
 } 

 get f() {
    return this.eventForm.controls;
  }

  get items(): FormArray {
    return this.eventForm.get('items') as FormArray;
  }

  addItem(): void {
    if (this.items.length < 5) {
      this.items.push(this.formBuilder.group({
         full_name: new FormControl('', [Validators.required]),
          username: new FormControl('', [Validators.required]),
          email: new FormControl('', [Validators.required]),
          mobile: new FormControl('', [Validators.required]),
          id_proof: new FormControl('', [Validators.required]),
      }));



      this.commonServe.total_member = this.commonServe.total_member+1;
      this.commonServe.sub_total = (this.commonServe.total_member*this.eventPrice);
      this.commonServe.discount_price = this.commonServe.discount_price;
this.commonServe.final_amount = ((this.commonServe.total_member*this.eventPrice) - (this.commonServe.discount_price)); 

     }else{
       this.toastr.errorToastr("Maximum 5 member add...",'Error!');
     }
  }

  removeItem(index: number): void {
    this.items.removeAt(index);

    this.commonServe.total_member = this.commonServe.total_member-1;
    this.commonServe.sub_total = (this.commonServe.total_member*this.eventPrice);
    this.commonServe.discount_price = this.commonServe.discount_price;
    this.commonServe.final_amount = ((this.commonServe.total_member*this.eventPrice) - (this.commonServe.discount_price)); 
  }

  public removesecondForm(){
    $('#secondForm').hide();

    this.eventForm = this.formBuilder.group({
      full_name: new FormControl('', [Validators.required]),
      username: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required]),
      mobile: new FormControl('', [Validators.required]),
      id_proof: new FormControl('', [Validators.required]),

      full_name1: new FormControl(''),
      username1: new FormControl(''),
      email1: new FormControl(''),
      mobile1: new FormControl(''),
      id_proof1: new FormControl(''),
      

      items: this.formBuilder.array([])
      
    });
    this.commonServe.total_member = this.commonServe.total_member-1;
    this.commonServe.sub_total = (this.commonServe.total_member*this.eventPrice);
    this.commonServe.discount_price = this.commonServe.discount_price;
    this.commonServe.final_amount = ((this.commonServe.total_member*this.eventPrice) - (this.commonServe.discount_price)); 

  }

  public getallFriendRequest(event_id){

    var obj={
      'event_id':event_id
    }
    this.callapi.post('/events/get_single_events',obj).subscribe(data => {
       if(data.status == 200){
          this.allEventData = data.data;
          this.eventPrice = this.allEventData.event_price;

           this.callapi.get('/user/me').subscribe(data => {
            if(data.status=='200'){
              this.userData = data.data;
              this.eventProfileType = this.userData.profile_type;
              // alert(this.userData.profile_type);

              this.priceCalculation(this.userData.username);
              if(this.userData.profile_type == 'single'){
                this.eventForm.controls["full_name"].setValue(this.userData.single_full_name);
                this.eventForm.controls["username"].setValue(this.userData.username);
                this.eventForm.controls["email"].setValue(this.userData.email);

              }else if(this.userData.profile_type == 'couple'){

                this.eventForm.controls["full_name"].setValue(this.userData.couple_full_name_from);
                this.eventForm.controls["username"].setValue(this.userData.username);
                this.eventForm.controls["email"].setValue(this.userData.email);

                this.eventForm.controls["full_name1"].setValue(this.userData.couple_full_name_to);
                this.eventForm.controls["username1"].setValue(this.userData.username);
                this.eventForm.controls["email1"].setValue(this.userData.email);

              }else{
                this.eventForm.controls["full_name"].setValue(this.userData.single_full_name);
                this.eventForm.controls["username"].setValue(this.userData.username);
                this.eventForm.controls["email"].setValue(this.userData.email);
              }
              


            }else{
              this.userData = '';
            }
         }); 
          
        }else{
          this.allEventData = '';
        }
    }); 

   
  }

  public hideShowPromo(){
    if ($('#promo_text').hasClass('coupon_hide')){
      $('#promo_text').removeClass('coupon_hide');
      $('#promo_text').addClass('coupon_show');
    }else{
      $('#promo_text').addClass('coupon_hide');
      $('#promo_text').removeClass('coupon_show');
    }
  }

  public hideShowRoom(){
     if ($('#room_text').hasClass('room_hide')){
      $('#room_text').removeClass('room_hide');
      $('#room_text').addClass('room_show');
    }else{
      $('#room_text').addClass('room_hide');
      $('#room_text').removeClass('room_show');
    }
  }

  public checkPromo(){
    var promo_code = $('#promo_code').val();
    if(promo_code ==''){
      this.toastr.errorToastr("Please enter a promo code",'Error!');
     }else{
         var obj={
          'promo_code':promo_code,
          'amount':this.commonServe.sub_total,
          'discount_price':this.commonServe.discount_price,
          'room_price':this.commonServe.room_price,
        }
        $('#preloader').show();
        this.callapi.post('/events/check_promo',obj).subscribe(data => {
          $('#preloader').hide();
           if(data.status == 200)
           {

             this.toastr.successToastr(data.mesaage, 'Success!');
             this.commonServe.promo_code_id = data.data.promo_code_id;
             this.commonServe.sub_total = data.data.sub_total;
             this.commonServe.discount_price = data.data.discount_price;
             this.commonServe.final_amount = data.data.final_amount;


            
            }else{

              
              this.toastr.errorToastr(data.message,'Error!');
             this.commonServe.promo_code_id = data.data.promo_code_id;
             this.commonServe.sub_total = data.data.sub_total;
             this.commonServe.discount_price = data.data.discount_price;
             this.commonServe.final_amount = data.data.final_amount;
            }
        },error => {
            $('#preloader').hide();
            this.toastr.errorToastr('Some ERROR occured!Please try again...', 'Error!');
       });
     }
    
  }


  public getRoom(type){
     var obj={
          'room_type':type,
        }
        this.callapi.post('/events/get_all_room',obj).subscribe(data => {
           if(data.status == 200)
           {
             this.roomData = data.data;
             $('#room_details').css('display','block')
           }else{
             this.roomData = '';
             this.toastr.errorToastr(data.message,'Error!');
             
            }
        }); 
      
  }

  public selectRoom(room_details){
    this.commonServe.sub_total = this.commonServe.sub_total;
    
    this.commonServe.discount_price = this.commonServe.discount_price;
    this.commonServe.room_price = room_details.price;
    this.commonServe.room_name = room_details.room_name;
    this.commonServe.room_id = room_details.id;
    
   var final_amount1 = Number(this.commonServe.sub_total) + Number(this.commonServe.room_price);

    this.commonServe.final_amount = Number(final_amount1) - Number(this.commonServe.discount_price);

  }

  public buyNow(){

      const data = this.eventForm.value;
      console.log(data);

      if (this.eventForm.valid) 
      {
          this.submitted = false;
          alert('123');
      }else{
          alert('456');
           this.submitted = true;
           return;
      }


    
    // var error =0;
    // var f_name_member_1 = $('#f_name_member_1').val();
    // var l_name_member_1 = $('#l_name_member_1').val();
    // var email_member_1 = $('#email_member_1').val();
    // var phone_member_1 = $('#phone_member_1').val();
    // var f_name_member_2 = $('#f_name_member_2').val();
    // var l_name_member_2 = $('#l_name_member_2').val();
    // var email_member_2 = $('#email_member_2').val();
    // var phone_member_2 = $('#phone_member_2').val();

    // // alert(this.id_proof_2);
    // // var id_proof 
    // // addNewMemberFlag
    // if((f_name_member_1 == '') || (l_name_member_1 == '') || (email_member_1 == '') || (phone_member_1 == '') || (this.id_proof_1 == '')){
    //   this.toastr.errorToastr('Member 1 All Field Required....','Error!');
    //   error=1;
    // }else{
    //   error=0;
    // }

    // if(this.addNewMemberFlag == true){
    //     if((f_name_member_2 == '') || (l_name_member_2 == '') || (email_member_2 == '') || (phone_member_2 == '') || (this.id_proof_2 == '')){
    //         this.toastr.errorToastr('Member 2 All Field Required....','Error!');
    //         error=1;
    //       }else{
    //         error=0;
    //       }
    // }

    // // alert(error);
    // if(error == 0){
    //      var obj={
    //       'event_id':this.event_id,
    //       'promo_code_id':this.commonServe.promo_code_id,
    //       'room_id':this.commonServe.room_id,
    //       'sub_total':this.commonServe.sub_total,
    //       'discount_price':this.commonServe.discount_price,
    //       'room_price':this.commonServe.room_price,
    //       'final_amount':this.commonServe.final_amount,
    //       'f_name_member_1':f_name_member_1,
    //       'f_name_member_2':f_name_member_2,
    //       'l_name_member_1':l_name_member_1,
    //       'l_name_member_2':l_name_member_2,
    //       'email_member_1':email_member_1,
    //       'email_member_2':email_member_2,
    //       'phone_member_1':phone_member_1,
    //       'phone_member_2':phone_member_2,
    //       'id_proof_1':this.id_proof_1,
    //       'id_proof_2':this.id_proof_2,
         
    //     }
    //       $('#preloader').show();
    //      this.callapi.post('/events/book_ticket',obj).subscribe(data => {
    //        $('#preloader').hide();
    //          if(data.status == 200)
    //          {
    //            $('#preloader').hide();
    //            this.toastr.successToastr(data.message,'Success!');
    //            this.router.navigateByUrl('/events');
    //          }else{
    //            $('#preloader').hide();
    //            this.toastr.errorToastr(data.message,'Error!');
    //          }
    //       },error => {
    //          $('#preloader').hide();
    //          this.toastr.errorToastr('Some ERROR occured!Please try again...', 'Error!');
                    
    //       });
    // }

   
        
    
    

   
  }

  onFileChange(event: Event): void {

    const input = event.target as HTMLInputElement;

    if (input.files && input.files.length) {
      const file = input.files[0];
      const reader = new FileReader();

      reader.onload = () => {
        this.base64Image1 = reader.result;
        // console.log(reader.result);

        var obj ={
          'image':reader.result
        }
      $('#preloader').show();
      this.callapi.post('/upload/imageupload', obj).subscribe(result => {
      
        
        if ((result.status == 200) || (result.status === '200')) {
           $('#preloader').hide();
          this.toastr.successToastr(result.message, 'Success!');
         this.eventForm.controls["id_proof"].setValue(result.data);
         // this.eventForm.controls["id_proof"].setValue(result.data);
         console.log("v>>>>>>>>>",this.eventForm);
        } else {
          $('#preloader').hide();
          this.toastr.errorToastr(result.message, 'Error!');
       }
      },err => {
        $('#preloader').hide();
      });
        
      };

      reader.readAsDataURL(file);
    }
  }


  onFileChange1(event: Event): void {

    const input = event.target as HTMLInputElement;

    if (input.files && input.files.length) {
      const file = input.files[0];
      const reader = new FileReader();

      reader.onload = () => {
        this.base64Image1 = reader.result;
        // console.log(reader.result);

        var obj ={
          'image':reader.result
        }
      $('#preloader').show();
      this.callapi.post('/upload/imageupload', obj).subscribe(result => {
      
        
        if ((result.status == 200) || (result.status === '200')) {
           $('#preloader').hide();
          this.toastr.successToastr(result.message, 'Success!');
         this.eventForm.controls["id_proof1"].setValue(result.data);
         // this.eventForm.controls["id_proof"].setValue(result.data);
         console.log("v>>>>>>>>>",this.eventForm);
        } else {
          $('#preloader').hide();
          this.toastr.errorToastr(result.message, 'Error!');
       }
      },err => {
        $('#preloader').hide();
      });
        
      };

      reader.readAsDataURL(file);
    }
  }


  onFileChangeAddMore(event: any, index: number): void {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      const file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {

         var obj ={
          'image':reader.result
        }

        this.callapi.post('/upload/imageupload', obj).subscribe(result1 => {
         $('#preloader').hide();
          
          if ((result1.status == 200) || (result1.status === '200')) {

            this.toastr.successToastr(result1.message, 'Success!');
            this.items.at(index).get('id_proof').setValue(result1.data);

          } else {
            $('#preloader').hide();
            this.toastr.errorToastr(result1.message, 'Error!');
            
          }
        },err => {
          $('#preloader').hide();
        });



        
      };
    }
  }

  // onFileChange(event: any): void {
  //   $('#myModal').modal('show');
  //    this.imgChangeEvt = event;
  // }

  // cropImg(e: ImageCroppedEvent) {
  //   this.cropImgPreview = e.base64;
  // }

  // crop(){

  //   this.imageupload(this.cropImgPreview);
  //   // alert(this.cropImgPreview);
  // }

  // cancelCrop(){
  //   $('#myModal').modal('hide');
  // }

  // public imageupload(base64){

  //   var obj ={
  //     'image':base64
  //   }
  //   $('#preloader').show();
  //   this.callapi.post('/upload/imageupload', obj).subscribe(result => {
  //      $('#preloader').hide();
        
  //       if ((result.status == 200) || (result.status === '200')) {

  //         this.toastr.successToastr(result.message, 'Success!');
  //         this.id_proof_1 =result.data;   
  //         $('#myModal').modal('hide');

  //       } else {
  //         $('#preloader').hide();
  //         this.toastr.errorToastr(result.message, 'Error!');
          
  //       }
  //     },err => {
  //       $('#preloader').hide();
  //     });
  // }


  // onFileChangeNew(event: any): void {

  //   $('#myModalNew').modal('show');
  //   this.imgChangeEvtNew = event;
  //   // alert(this.imgChangeEvt);
  // }

  // cropImgNew(e: ImageCroppedEvent) {
  //   this.cropImgPreviewNew = e.base64;
  // }

  // cropNew(){

  //   this.imageuploadNew(this.cropImgPreviewNew);
  //   // alert(this.cropImgPreview);
  // }

  // cancelCropNew(){
  //   $('#myModalNew').modal('hide');
  // }

  // public imageuploadNew(base64){

  //   var obj ={
  //     'image':base64
  //   }
  //   this.callapi.post('/upload/imageupload', obj).subscribe(result => {
  //      $('#preloader').hide();
        
  //       if ((result.status == 200) || (result.status === '200')) {

  //         this.toastr.successToastr(result.message, 'Success!');
  //         this.id_proof_2 =result.data;   
  //         $('#myModalNew').modal('hide');

  //       } else {
  //         $('#preloader').hide();
  //         this.toastr.errorToastr(result.message, 'Error!');
          
  //       }
  //     },err => {
  //       $('#preloader').hide();
  //     });
  // }

  public priceCalculation(username){

    this.usenameArray.push({username});

    if(this.eventProfileType == 'single'){
      this.commonServe.total_member = 1;
      this.commonServe.sub_total = this.eventPrice;
      this.commonServe.discount_price = 0;
      this.commonServe.final_amount = this.eventPrice; 
      // this.getUserName(username);
    }else if(this.eventProfileType == 'couple'){
      this.commonServe.total_member = 2;
      this.commonServe.sub_total = (2*this.eventPrice);
      this.commonServe.discount_price = 0;
      this.commonServe.final_amount = (2*this.eventPrice); 
      // this.getUserName(username);
    }else{
      this.commonServe.total_member = 1;
      this.commonServe.sub_total = this.eventPrice;
      this.commonServe.discount_price = 0;
      this.commonServe.final_amount = this.eventPrice; 
      // this.getUserName(username);

    } 

    
  }

  // getUserName(obj) {
  //   if (obj != '') {
  //     this.callapi.get('/membership/check_username_membership/' + obj).subscribe(result => {
        
  //         if((result.status === '200')) {

  //           if(result.membership_expire == 'No'){
  //             this.commonServe.total_member = this.commonServe.total_member;
  //             this.commonServe.sub_total = this.commonServe.sub_total;
  //             this.commonServe.discount_price = this.commonServe.discount_price;

  //             var obj={
  //               "username":result.username,
  //               "message":"Membership Discount",
  //               "membership_discount_price":result.membership_discount_price
  //             }
  //             this.membershipArray.push(obj);


  //             console.log('this.membershipArray',this.membershipArray);

  //             var discount_price =  this.membershipArray.reduce((total, item) => parseInt(total) + parseInt(item.membership_discount_price), 0);

  //             console.log('discount_price',discount_price);
              
  //             this.commonServe.final_amount = (this.commonServe.final_amount - discount_price);
  //           }else{
  //             this.commonServe.total_member = this.commonServe.total_member;
  //             this.commonServe.sub_total = this.commonServe.sub_total;
  //             this.commonServe.discount_price = this.commonServe.discount_price;
  //             this.commonServe.final_amount = this.commonServe.final_amount;
  //           }

            
  //           // this.uservalue = 'You are a member of Blaster Gate';
  //           // this.userflag = 1;
  //         } else {
  //           this.commonServe.total_member = this.commonServe.total_member;
  //           this.commonServe.sub_total = this.commonServe.sub_total;
  //           this.commonServe.discount_price = this.commonServe.discount_price;
  //           this.commonServe.final_amount = this.commonServe.final_amount;
  //           // this.uservalue = 'You are not a member of Blaster Gate';
  //           // this.userflag = 0;
  //         }

        
  //     }, err => {
        
  //     });
  //   }


  // }


  // getUserName(username:string) {
  //   alert(username);
  //   if (!this.isUsernameTaken(username)) {
  //     this.usenameArray.push({username});
  //   } else {
  //     this.toastr.errorToastr('Username already use. Please choose different username', 'Error!');
  //   }

  //   console.log(this.usenameArray);

  // }

  // setUserNameOnFocus(obj) {
  //   obj = '';
  //   this.showname = '';
  //   this.showflag = 0;
  // }


  // isUsernameTaken(username: string): boolean {
  //   return this.usenameArray.some(user => user.username === username);
  // }


}
