import { Component, EventEmitter, Input, OnInit, Output,ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { NgModule } from '@angular/core';
import { Observable } from 'rxjs'; 
import { BrowserModule } from '@angular/platform-browser';
import { map, startWith } from 'rxjs/operators';
import * as service from '../../../api-service/service/index';
import { Router,ActivatedRoute } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';

import { PasswordMatchPattern } from '../../../api-service/all-validation-pattern/password-match-pattern';
import { MobilePatternValidator } from '../../../api-service/all-validation-pattern/mobile-pattern-validator';

declare const $: any;
declare const google: any;
import AOS from 'aos';
import 'aos/dist/aos.css';

import { ImageCroppedEvent } from 'ngx-image-cropper';


@Component({
  selector: 'app-view-user-pay-per-click',
  templateUrl: './view-user-pay-per-click.component.html',
  styleUrls: ['./view-user-pay-per-click.component.css']
})
export class ViewUserPayPerClickComponent implements OnInit {

  
  data: any;
  myParams: object = {};
  myStyle: object = {};
  public regData: any = {};
  public submitted = false;
  public emailotp;

  public infoText;
  public profile_type='private';
  public selected_date;

  public pay_per_terms_condition;
  public allChocolateData;
  public singleChocolateData;

  public chocolateDataFlag:boolean=false;
  public chocolateData1Flag:boolean=false;

  public profileDataMeImage;
  public profileDataAllImage;
  public pay_per_id;
  public calender_details;
  public viewClanederFlag:boolean=true;
  public laderFlag:boolean=false;

  constructor(private formBuilder: FormBuilder,
                private callapi: service.CallApiService,
                private tokenSaveService: service.CanTokenSaveService,
                private router: Router,
                private toastr: ToastrManager,
                private tokenRemoveService: service.CanTokenRemoveService,
                public commonServe: service.CommonService,private activatedRoute: ActivatedRoute)
  { 
    if (!(this.tokenSaveService.getAccessToken())) {
        this.router.navigateByUrl('/home');
    }
  }

  ngOnInit() {
     $('#preloader').hide();
     if(this.commonServe.pay_per_id){
       this.commonServe.pay_per_id = this.commonServe.pay_per_id;
     }else{
       this.commonServe.pay_per_id = atob(this.activatedRoute.snapshot.queryParams["id"]);
     }
    this.getSingleChocolateFactory(this.commonServe.pay_per_id); 
    this.getAllChocolateFactory();
 
    
 }


  public getSingleChocolateFactory(pay_per_id){

   var obj={
     "id":pay_per_id
   }
    this.callapi.post('/payperclick/get_single_chocolate_factory',obj).subscribe(data => {
       $('#preloader').hide();
       if(data.status == 200){
          this.singleChocolateData = data.data[0];
          this.profileDataMeImage = this.singleChocolateData.image[0].profile_image;
          this.laderFlag=true;
          
          
        }else{
           this.laderFlag=true;
          this.singleChocolateData = '';
         
         
        }
    }); 
  }

  public getAllChocolateFactory(){

     var obj={
     "user_type":"other"
   }
    this.callapi.post('/payperclick/get_chocolate_factory_data',obj).subscribe(data => {
       if(data.status == 200){
          this.allChocolateData = data.data;
          // this.profileDataAllImage = this.allChocolateData.image[0].profile_image;
         }else{
          this.allChocolateData = '';
        }
    }); 
  }

  
  public viewUserPayPerClick(id){
     $('#preloader').show();
      setTimeout(() => {
        this.commonServe.pay_per_id = id;
        $('#preloader').hide();
       this.getSingleChocolateFactory(this.commonServe.pay_per_id);
       this.router.navigate(['/view-user-pay-per-click'], { queryParams: { id: btoa(this.commonServe.pay_per_id) }});  
       }, 2000);

   }


  public viewCalenderDetails(id){
    this.getCalenderDetails(id);
  }

  public getCalenderDetails(pay_per_id){

   var obj={
     "pay_per_id":pay_per_id
   }
    this.callapi.post('/payperclick/get_user_calender_details',obj).subscribe(data => {
       $('#preloader').hide();
       if(data.status == 200){
          this.calender_details = data.data;
          this.viewClanederFlag=true;
          $('#calenderModal').modal('show');
           
        }else{
          this.calender_details = '';
          this.viewClanederFlag=false;
          $('#calenderModal').modal('show');
         
        }
    }); 
  }

  public viewPhoto(id){
    this.router.navigate(['/view-user-photo'], { queryParams: { id: btoa(id) }}); 
  }

  public viewVideo(id){
    this.router.navigate(['/view-user-video'], { queryParams: { id: btoa(id) }}); 
  }

  public addReview(id){
    this.router.navigate(['/add-pay-per-review'], { queryParams: { id: btoa(id) }}); 
  }

  // this.router.navigate(['/book-event-user'], { queryParams: { event_id: btoa(event_id) }}); 

}
