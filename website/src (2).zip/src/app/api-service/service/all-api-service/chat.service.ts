import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { io, Socket } from 'socket.io-client';
 
@Injectable({
	providedIn: 'root'
})
export class ChatService {

	private socket: Socket;
	public userdata:any;
	// private url = 'http://localhost:3000'; // your server local path
    private url = 'http://68.178.200.197:3000';
	constructor() {

		// alert(this.url);

		this.socket = io(this.url, {transports: ['websocket', 'polling', 'flashsocket']});

		this.userdata = JSON.parse(<string>localStorage.getItem("chatapp_user_data"));
		if(this.userdata){
			this.socket.emit('login',{userId:this.userdata['userid']});
		}
	    // console.log('this userdata', this.userdata['userid']);
		

		// this.socket.emit('alluserlist');
	}

	joinRoom(data): void {
		this.socket.emit('join', data);
	}

	sendMessage(data): void {
		this.socket.emit('message', data);
	}

	getMessage(): Observable<any> {
		return new Observable<{user: string, message: string}>(observer => {
			this.socket.on('new message', (data) => {
				observer.next(data);
			});

			return () => {
				this.socket.disconnect();
			}
		});
	}

	getStorage() {
		const storage: string = localStorage.getItem('chats');
		return storage ? JSON.parse(storage) : [];
	}

	setStorage(data) {
		localStorage.setItem('chats', JSON.stringify(data));
	}

}
