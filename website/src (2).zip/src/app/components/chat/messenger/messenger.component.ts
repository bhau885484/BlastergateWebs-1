import { Component, EventEmitter, Input, OnInit, Output,ViewChild ,ElementRef, AfterViewInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { NgModule } from '@angular/core';
import { Observable } from 'rxjs'; 
import { BrowserModule } from '@angular/platform-browser';
import { map, startWith } from 'rxjs/operators';
import * as service from '../../../api-service/service/index';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { ChatService } from '../../../api-service/service/all-api-service/chat.service';

import { PasswordMatchPattern } from '../../../api-service/all-validation-pattern/password-match-pattern';
import { MobilePatternValidator } from '../../../api-service/all-validation-pattern/mobile-pattern-validator';
import { environment } from '../../../../environments/environment';



declare const $: any;
declare const google: any;
// import AOS from 'aos';
// import 'aos/dist/aos.css';

import { ImageCroppedEvent } from 'ngx-image-cropper';

import AC from 'agora-chat';


@Component({
  selector: 'app-messenger',
  templateUrl: './messenger.component.html',
  styleUrls: ['./messenger.component.css']
})
export class MessengerComponent implements OnInit {

  public imageUrl = environment.chat_image_url;

  public roomId: string;
  public messageText: string;
  public messageArray: { user: string, message: string }[] = [];
  private storageArray = [];

  public showScreen = true;
  public phone: string;
  public pswd: string;
  public currentUser:any;
  public selectedUser:any;
  public userdata:any;
  public user_id_config:any = {};
  public userList:any = [];
  public userListAll:any = [];
  public totalMessages = 0;
public base64Image1;
public chatImage;
 public membershipFlag :boolean=false;
 public login_user_id;

@ViewChild('chatContainer', { static: false }) chatContainer!: ElementRef;

  constructor(private formBuilder: FormBuilder,
                private callapi: service.CallApiService,
                private tokenSaveService: service.CanTokenSaveService,
                private router: Router,
                private toastr: ToastrManager,
                private tokenRemoveService: service.CanTokenRemoveService,
                public commonServe: service.CommonService,private chatService: ChatService,)
  { 
    if (!(this.tokenSaveService.getAccessToken())) {
        this.router.navigateByUrl('/home');
    }
  }

  ngOnInit() {

    setTimeout(() => {
      if (this.tokenSaveService.getUserMembership() == 'Yes'){
         this.membershipFlag = false;
         $('#membershipModal').modal('show');
       }else{
         $('#membershipModal').modal('hide');
         this.membershipFlag = true;
         // setTimeout(() => {
         //   this.initMap();
         //    }, 2000);
          
       }
     
     }, 2000);

     this.scrollToBottom();
      setTimeout(() => {
        $('#right_side_togle').removeClass('show_toggle');
        $('#right_side_togle').addClass('hide_toggle');

        $('#big_tab').removeClass('col-lg-8');
        $('#big_tab').addClass('col-lg-10');
         this.initial();
     }, 500);


     this.login_user_id = this.tokenSaveService.getUserId();  
   

    this.chatService.getMessage().subscribe((data: any) => {

      console.log("new message", data);
      if(this.roomId == data.room){
        this.messageArray.push(data);
        this.scrollToBottom();
        console.log('messageArray',this.messageArray);
      }
    });
    
 }

 private scrollToBottom() {
    if (this.chatContainer) {
      this.chatContainer.nativeElement.scrollTop = 0; // Scroll to the top of the reversed container
    }
  }


initial(){
    this.userdata = JSON.parse(<string>localStorage.getItem("chatapp_user_data"));
    console.log('this userdata', this.userdata);

    this.currentUser = this.userdata;
    this.commonServe.getAllUsers(this.userdata['userid']).then(resp => {
      $('#preloader').hide();
      console.log("User getAllUsers", resp);
      if(resp.result == "success"){
        if('room_ids' in resp) this.currentUser['roomId'] = resp['room_ids'];
        this.userList = resp['data'];
        this.userListAll = resp['data'];
        console.log(this.currentUser, this.userList);
        for (let index = 0; index < this.userList.length; index++) {
          const element = this.userList[index];
          this.user_id_config[element.id] = element;
        }
        this.user_id_config[this.currentUser.userid] = this.userdata
      }else{
        alert("Users not found.");
        this.userList = [];
      }
    }).catch(err => {
      alert("Got error while processing the request. Please try again.");
      console.log("Error", err);
    })

     // setTimeout(() => {
     //    this.initial();
     //  }, 10000);
  }

selectUserHandler(email: string): void {
    this.selectedUser = this.userList.find(user => user.email === email);
    console.log(this.selectedUser, this.currentUser);

    this.roomId = this.currentUser.roomId[this.selectedUser.id];
    this.messageArray = [];

    this.commonServe.getAllMessages(this.currentUser.userid, this.selectedUser.id).then(resp => {
      console.log("User getAllMessages", resp, this.user_id_config);
      if(resp.result == "success"){
        let msgsConversation = resp['data'];
        for (let index = 0; index < msgsConversation.length; index++) {
          const element = msgsConversation[index];
          msgsConversation[index]['user'] = this.user_id_config[element['from_user']].username;
          msgsConversation[index]['message'] = element['text'];
        }
        msgsConversation.sort((a:any, b:any) => new Date(a.created_at).valueOf() - new Date(b.created_at).valueOf());
        console.log("message: ", msgsConversation);
        this.messageArray = msgsConversation;
      }else{
        alert("Users not found.");
        this.userList = [];
      }
    }).catch(err => {
      alert("Got error while processing the request. Please try again.");
      console.log("Error", err);
    })

    this.storageArray = this.chatService.getStorage();
    const storeIndex = this.storageArray.findIndex((storage) => storage.roomId === this.roomId);

    if (storeIndex > -1) {
      this.messageArray = this.storageArray[storeIndex].chats;
    }

    this.join(this.currentUser.username, this.roomId);
  }

  join(username: string, roomId: string): void {
    this.chatService.joinRoom({user: username, room: roomId});
  }

  sendMessage(): void {
    this.chatService.sendMessage({
      user: this.currentUser.username,
      image: this.chatImage,
      room: this.roomId,
      message: this.messageText,
      from_user: this.currentUser.userid,
      to_user: this.selectedUser.id
    });
    console.log('this.currentUser.username',this.currentUser.username);
    console.log('this.roomId',this.roomId);
    console.log('this.messageText',this.messageText);
    console.log('this.currentUser.id',this.currentUser.userid);
    console.log('this.selectedUser.id',this.selectedUser.id);
    console.log('this.image',this.chatImage);
    this.messageText = '';
  }

   public searchUser(value) {
     var searchVal = value.toLowerCase();
     console.log(this.userListAll);
     if(searchVal == ''){
       this.userList = this.userListAll;
     }else{
      this.userList = this.userListAll.filter(item =>
        Object.keys(item).some(key => 
          item[key].toString().toLowerCase().indexOf(searchVal.toLowerCase()) !== -1
        )
      );
     }

    //  var searchVal = value.toLowerCase();
    
  }


  onFileChange(event: Event): void {

    const input = event.target as HTMLInputElement;

    if (input.files && input.files.length) {
       const file = input.files[0];
       const reader = new FileReader();
       reader.onload = () => {
        this.base64Image1 = reader.result;
        // console.log(reader.result);

        var obj ={
          'image':reader.result
        }
      $('#preloader').show();
      this.callapi.post('/upload/imageupload', obj).subscribe(result => {
      
        if ((result.status == 200) || (result.status === '200')) {
           $('#preloader').hide();
          // this.toastr.successToastr(result.message, 'Success!');
           this.chatImage = result.data;
            this.sendMessage();
        } else {
          $('#preloader').hide();
          this.toastr.errorToastr(result.message, 'Error!');
       }
      },err => {
        $('#preloader').hide();
      });
        
      };

      reader.readAsDataURL(file);
    }
  }

  public linkRouter(link){
    $('#membershipModal').modal('hide');
    $('#preloader').show();
    this.router.navigate([link]);
  }



}
