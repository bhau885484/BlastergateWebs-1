export const environment = {
  production: true,
  chat_image_url:'https://api.blastergate.com/assets/',
  api_url:'https://api.blastergate.com/App',
  agora_chat_url:'https://a71.chat.agora.io/711245752/1441455'
};

