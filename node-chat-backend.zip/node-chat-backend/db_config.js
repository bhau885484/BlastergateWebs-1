const db_config = {
    db: { 
        // host: "localhost",
        // user: "root",
        // password: "",
        // database: "blastergate",

        host: "68.178.200.197",
        user: "bgdotcom_blastergate",
        password: "blastergate@123456",
        database: "bgdotcom_blastergate",

        // host: "184.168.123.80",
        // user: "crmtd_blastergate",
        // password: "blastergate@123456",
        // database: "crmtd_blastergate",
    
    }
}

module.exports = db_config