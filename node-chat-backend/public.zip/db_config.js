const db_config = {
    db: { 
        // host: "localhost",
        // user: "root",
        // password: "",
        // database: "blastergate",

        host: "198.12.236.68",
        user: "blastergate",
        password: "blastergate@12345678",
        database: "blastergate",
    }
}

module.exports = db_config