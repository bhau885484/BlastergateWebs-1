var dbObj = require('./db')

// example
async function getConnectedUsers(user){
    try{
        const resp = await dbObj.query(`select room_id,from_user,to_user from tbl_chat_rooms where (from_user = '${user}') or (to_user = '${user}')`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in getAllUser");
        return null;
    }
}

async function getUsersInfo(userList){
    try{
       
        const resp = await dbObj.query(`SELECT tbl_users.id,tbl_users.email,tbl_users.username,tbl_users.profile_type,tbl_users.gender_profile_type,tbl_users.image_type,tbl_users.last_login,tbl_users.last_login,tbl_users.status, tbl_profile_image.image FROM tbl_users LEFT JOIN tbl_profile_image ON tbl_users.id = tbl_profile_image.user_id  where tbl_users.id in (${userList}) GROUP BY tbl_profile_image.user_id`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in getUsersInfo");
        return null;
    }
}


async function getUsersImageInfo(userid){
    try{
        
        const resp = await dbObj.query(`select * from tbl_profile_image where user_id  = ${userid}`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in getUsersInfo");
        return null;
    }
}

async function checkUser(email, pswd) {
    try {
        const resp = await dbObj.query(`select * from tbl_users where (email = '${email}' and password = '${pswd}')`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in checkUser");
        return null;
    }
}

async function authUser(id, cookie) {
    try {
        const resp = await dbObj.query(`select username from tbl_users where id = ${id}`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in authUser");
        return null;
    }
}

async function getRoomId(user1, user2) {
    try {
        const resp = await dbObj.query(`select id,room_id from rooms where (user1 = ${user1} and user2 = ${user2}) or (user1 = ${user2} and user2 = ${user1})`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in getRoomId");
        return null;
    }
}

async function getMessages(user1, user2) {
    try {
        const resp = await dbObj.query(`select id,text,from_user,to_user,created_at,time_at from tbl_chat_messages where (from_user = ${user1} and to_user = ${user2}) or (from_user = ${user2} and to_user = ${user1})`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in getMessages");
        return null;
    }
}

async function addMessage(from_user, to_user, text) {
    try {
        const currentDate = new Date().toISOString().split('T')[0];
        const currentTime = new Date();
        currentTime.setHours(currentTime.getHours() + 12); // Add 12 hours to current time
        const formattedTime = currentTime.toLocaleTimeString('en-US', { hour12: false });

        const resp = await dbObj.query(`insert into tbl_chat_messages (from_user,to_user,text,created_at,time_at) values (${from_user},'${to_user}','${text}','${currentDate}','${formattedTime}')`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in createTask");
        return null;
    }
}

async function offlineUser(id) {
    try {
        const resp = await dbObj.query(`update tbl_users SET last_login = '0' where id = ${id}`);
        return JSON.parse(JSON.stringify(resp));
    } catch (error) {
        console.log("## ERROR in authUser");
        return null;
    }
}

module.exports = {
    getConnectedUsers, checkUser, authUser, offlineUser, getRoomId, getMessages, addMessage, getUsersInfo
}